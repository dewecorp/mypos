<?php

function check_already_login() {
    $ci =& get_instance();
    $user_session = $ci->session->userdata('userid');
    if($user_session) {
        redirect('dashboard');
    }
}

function check_not_login() {
    $ci =& get_instance();
    $user_session = $ci->session->userdata('userid');
    if(!$user_session) {
        redirect('auth/login');
    }
}

function check_admin() {
    $ci =& get_instance();
    $ci->load->library('fungsi');
    if($ci->fungsi->user_login()->level != 1) {
        redirect('dashboard');
    }
}

function indo_currency($nominal) {
    $result = "RP " . number_format($nominal, 2, '.', '.') ;
    return $result;
    }

function indo_date($date) {
    $d = substr($date,8,2);
    $m = substr($date,5,2);
    $y = substr($date,0,4);
    return $d.'/'.$m.'/'.$y;
    }

function time_ago($datetime, $timezone = 'Asia/Jakarta') {
    date_default_timezone_set($timezone);
    $ts = is_numeric($datetime) ? (int)$datetime : strtotime($datetime);
    $diff = time() - $ts;
    if($diff < 60) return $diff.' detik lalu';
    $diff = floor($diff/60);
    if($diff < 60) return $diff.' menit lalu';
    $diff = floor($diff/60);
    if($diff < 24) return $diff.' jam lalu';
    $diff = floor($diff/24);
    return $diff.' hari lalu';
}

function format_tz($datetime, $timezone = 'Asia/Jakarta', $format = 'Y-m-d H:i:s') {
    $tz = new DateTimeZone($timezone);
    if (is_numeric($datetime)) {
        $dt = new DateTime('@'.$datetime);
        $dt->setTimezone($tz);
    } else {
        $dt = new DateTime($datetime);
        $dt->setTimezone($tz);
    }
    return $dt->format($format);
}
